import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.List;
 
/**
 * @author Suxin Ji
 *
 */
public class Bullet extends Object implements Constant {
	
	Tank.Direction dir = Tank.Direction.R;

	private boolean live = true;
	private boolean good;
	
	public boolean isGood() {
		return good;
	}
	
	public boolean isLive() {
		return live;
	}
	
	public Bullet(int x, int y, Tank.Direction dir) {
		super(x, y);
		this.dir = dir;
	}
	
	public Bullet(int x, int y, Tank.Direction dir,boolean good,TankClient tc) {
	    super(x, y);
		this.dir = dir;
		this.good = good;   //The good attribute of tank is consistent with the good attribute of shell.
		this.tc = tc;
	}
	
	public void draw(Graphics g) {
		if(!this.live) {  // if the shell is dead, remove it from the container and return, instead of drawing it.
			tc.bullets.remove(this);
			return;
		}
		Color c = g.getColor();
		if(!this.isGood())
			g.setColor(new Color(160,160,160));
		else
			g.setColor(Color.BLUE);
		g.fillOval(x, y, BulletWidth, BulletHeight);
		g.setColor(c);	
		move();
	}
 
	public void move() {
		switch(dir) {
		case L: 
			x -= BulletVx;
			break;
		case LU:
			x -= BulletVx;
			y -= BulletVy;
			break;
		case LD:
			x -= BulletVx;
			y += BulletVy;
			break;
		case R:
			x += BulletVx;
			break;
		case RU:
			x += BulletVx;
			y -= BulletVy;
			break;
		case RD:
			x += BulletVx;
			y += BulletVy;
			break;
		case U:
			y -= BulletVy;
			break;
		case D:	
			y += BulletVy;
			break;		
		}
	
		if(x < 0 || y < 30 || x >tc.ScreenWide-10 || y>tc.ScreenHeight-10) {
			this.live = false;	// if the shell goes out, it dies	
		}
			
	}
	
	public Rectangle getRec() {
		return new Rectangle(x,y,BulletWidth,BulletHeight);
	}
	
	public boolean fireTanks(Tank t) {
		if(this.getRec().intersects(t.getRec()) && t.isLive() 
				&& this.good!=t.isGood()) {
			t.setLive(false);
			this.live = false;
			Explode e = new Explode(x,y,this.tc);
			e.setLive(true); 
			tc.explodes.add(e);
			return true;			
		}		
		return false;
	}
	
	public boolean fireTank(List<Tank> tanks) {
		for(int i=0;i<tanks.size();i++) {
			if(fireTanks(tanks.get(i)))
				return true;			
		}		
		return false;
	}
	
	
		
}

