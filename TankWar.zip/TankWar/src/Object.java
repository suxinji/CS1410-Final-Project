/**
 * @author Suxin Ji
 *
 */
import java.security.SecureRandom;
//This is a super class.
public class Object {
	
	protected int x;
	protected int y;
	protected TankClient tc;
	protected static SecureRandom random = new SecureRandom(); 
	
	public Object(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	

}
