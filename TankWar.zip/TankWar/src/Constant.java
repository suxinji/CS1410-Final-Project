/**
 * @author Suxin Ji
 *
 */
public interface Constant {
	
	public static final int TankVx = 4;
	public static final int TankVy = 4;
	public static final int BulletVx = 3;
	public static final int BulletVy = 3;
	public static final int ScreenWidth = 700;
	public static final int ScreenHeigh = 500; 
	public static final int Width = 25;
	public static final int	Height = 25;
	public static final int BulletWidth = 15;
	public static final int BulletHeight = 15;
	
	
}
