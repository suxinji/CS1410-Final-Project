/**
 * @author Suxin Ji
 *
 */
import java.awt.Color;
import java.awt.Graphics;
 
public class Explode extends Object {
 
	private boolean live = false;
	int [] diameter = {4,8,12,22,34,32,20,13,6};
	int step = 0;
	
	public boolean isLive() {
		return live;
	}
 
	public void setLive(boolean live) {
		this.live = live;
	}
 
	
	public Explode(int x,int y,TankClient tc) {
		super(x, y);
		this.tc = tc;		
	}
	
	public void draw(Graphics g) {
		if(!this.live) {	
			tc.explodes.remove(this);			
			return;
		}
		
		if(step == diameter.length) {
			step = 0;
			this.live = false;
			tc.explodes.remove(this);
		}
		Color c = g.getColor();
		g.setColor(Color.WHITE);
		g.fillOval(x, y, diameter[step], diameter[step]);
		g.setColor(c);	
		step++;
	}
	
}
