/**
 * @author Suxin Ji
 *
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class Tank extends Object implements Constant {

	enum Direction {
		D, L, LD, LU, R, RD, RU, STOP, U
	}

	private static int dm = random.nextInt(12) + 3;
	//Random number defined by
	boolean bL = false;
	boolean bR = false;
	boolean bU = false;
	boolean bD = false;
	boolean bB = false; // enumeration of types used to indicate the direction of movement of the tank also determines the direction of the shell
	private Direction dir = Direction.STOP;
	private Direction mdir = Direction.RD;
	private boolean Mytank = true; // used to distinguish between enemy and us tanks. If a tank's good property is true, it is our tank
	boolean live = true; // is used to indicate whether the tank is still alive or not. If the live attribute is false, the tank is not drawn and removed from the list container in the draw method.

	public Tank(int x, int y, boolean good) {
		super(x, y);
		this.Mytank = good;
	}

	public Tank(int x, int y, boolean good, Direction dir, TankClient tc) {
		super(x, y);
		this.Mytank = good;
		this.dir = dir;
		this.tc = tc;
	}

	// Overloading construct
	public Tank(int x, int y, boolean good, TankClient tc) {
		super(x, y);
		this.Mytank = good;
		this.tc = tc;
	}

	public void draw(Graphics g) {
		if (!this.isLive()) {
			if (!Mytank)
				tc.tanks.remove(this);
			// If the tank is enemy , and it is died, remove from list.
			return;
		}

		Color c = g.getColor();
		if (Mytank)
			g.setColor(new Color(255, 51, 153)); // enemy tanks and our tanks are painted in different colors
		else
			g.setColor(new Color(0,0,0));
		g.fillOval(x, y, Width, Height);
		g.setColor(Color.blue);
		move();

		switch (mdir) { // draw the battery of the tank. The direction of the battery is the last movement direction of the tank.
		case L:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x, y + Tank.Height / 2);
			break;
		case LU:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x, y);

			break;
		case LD:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x, y + Tank.Height);

			break;
		case R:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x + Tank.Width, y + Tank.Height / 2);

			break;
		case RU:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x + Tank.Width, y);

			break;
		case RD:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x + Tank.Width, y + Tank.Height);

			break;
		case U:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x + Tank.Width / 2, y);

			break;
		case D:
			g.drawLine(x + Tank.Width / 2, y + Tank.Height / 2, x + Tank.Width / 2, y + Tank.Height);

			break;
		case STOP:
			break;
		}
		g.setColor(c);

	}

	public Bullet fire() {

		int x = this.x + Tank.Width / 2 - Bullet.Width / 2;
		int y = this.y + Tank.Height / 2 - Bullet.Height / 2;

		// draw the position and direction of the shell according to the movement direction of the tank and position. The fourth attribute indicates that the enemy and enemy attributes of the shell are the same as those of the tank.
		Bullet m = new Bullet(x, y, mdir, Mytank, this.tc);
		tc.bullets.add(m);
		// add the shell to the container
		return m;// return the shell
	}

	public Rectangle getRec() {
		return new Rectangle(x, y, Tank.Width, Tank.Height);
	}

	public boolean isGood() {
		return Mytank;
	}

	public boolean isLive() {
		return live;
	}

	public void KeyPress(KeyEvent e) {

		int key = e.getKeyCode();
		switch (key) {
		case KeyEvent.VK_RIGHT:
			bR = true;
			break;
			
		case KeyEvent.VK_LEFT:
			bL = true;
			break;
			
		case KeyEvent.VK_UP:
			bU = true;
			break;
			
		case KeyEvent.VK_DOWN:
			bD = true;
			break;

		}
		locationDir();
	}

	public void keyReleased(KeyEvent e) {
		
		int key = e.getKeyCode();
		switch (key) {
		case KeyEvent.VK_RIGHT:
			bR = false;
			break;
		case KeyEvent.VK_LEFT:
			bL = false;
			break;
		case KeyEvent.VK_UP:
			bU = false;
			break;
		case KeyEvent.VK_DOWN:
			bD = false;
			break;
		case KeyEvent.VK_SPACE:
			// When tank survive, it can fire a bullet
			if (this.isLive()) // only when the tank is alive can it fire bullets.
				tc.bullet = fire();
			break;
		}
		locationDir();

	}

	public void locationDir() {// determine the direction according to the key pressed
		if (bR && !bL && !bU && !bD) {
			dir = Direction.R;
		} else if (bR && !bL && bU && !bD)
			dir = Direction.RU;
		else if (bR && !bL && !bU && bD)
			dir = Direction.RD;
		else if (!bR && bL && !bU && !bD)
			dir = Direction.L;
		else if (!bR && bL && bU && !bD)
			dir = Direction.LU;
		else if (!bR && bL && !bU && bD)
			dir = Direction.LD;
		else if (!bR && !bL && bU && !bD)
			dir = Direction.U;
		else if (!bR && !bL && !bU && bD)
			dir = Direction.D;
		else
			dir = Direction.STOP;
		
		if (dir != Direction.STOP) // mdir saves the last direction and the tank stops to keep the last direction.
			mdir = dir;
	}

	public void move() {

		switch (dir) { // update the tank position according to the direction
		case L:
			x -= TankVx;
			break;
		case LU:
			x -= TankVx;
			y -= TankVy;
			break;
		case LD:
			x -= TankVx;
			y += TankVy;
			break;
		case R:
			x += TankVx;
			break;
		case RU:
			x += TankVx;
			y -= TankVy;
			break;
		case RD:
			x += TankVx;
			y += TankVy;
			break;
		case U:
			y -= TankVy;
			break;
		case D:
			y += TankVy;
			break;
		case STOP:
			break;
		}

		if (x < 0) // tanks cannot be out of bounds
			x = 0;
		else if (x > tc.ScreenWide - Tank.Width)
			x = tc.ScreenWide - Tank.Width;
		if (y < 30)
			y = 30;
		else if (y > tc.ScreenHeight - Tank.Height)
			y = tc.ScreenHeight - Tank.Height;
		if (!Mytank) { // if it is an enemy tank, the movement direction is random.
			Direction[] dirs = Direction.values();
			int rn = random.nextInt(dirs.length - 1);
			dm--; // notice that dirs[dirs.length] is STOP.
			if (dm <= 0) {
				dir = dirs[rn];
				mdir = dir;
				dm = random.nextInt(35) + 3;
			}
			if (random.nextInt(50) > 35)
				this.fire();

		}

	}

	public void setLive(boolean live) {
		this.live = live;
	}

}
